# 자동화된 데이터 분석 AI 에이전트 (MVP)

CSV 파일을 업로드하면 **데이터 개요 + 자동 EDA + 4~6개 시각화 + LLM 인사이트 리포트**를 생성하는 Agentic 데이터 분석 앱입니다.

## 프로젝트 목표

- CSV 업로드 후 분석 과정을 자동화
- 데이터 구조와 결측/기초통계를 빠르게 파악
- 차트 기반 탐색 결과를 즉시 리포트로 제공
- GPT 기반 인사이트와 액션 아이템까지 한 번에 생성

## Agentic Workflow

```text
User (CSV Upload)
   ↓
Planner Agent
 ├── Data Agent (Pandas EDA)
 ├── Viz Agent (Matplotlib/Seaborn)
 └── Insight Agent (OpenAI GPT / Fallback)
   ↓
Report Composer (React UI)
```

## 주요 기능

### 1) Data Agent
- 데이터 로드 및 스키마 분석
- shape, dtype, 결측치, 중복 행 집계
- `describe()` 기반 수치형 통계 요약
- 범주형 카디널리티 요약

### 2) Viz Agent
- 자동 차트 선택 로직으로 4~6개 생성
- Histogram/KDE (수치형 분포)
- Sorted target scatter (Mercedes 노트북 스타일 반영)
- Categorical bar chart
- Correlation heatmap
- Numeric scatter pair
- Category vs target boxplot (가능 시)

### 3) Insight Agent
- 입력 컨텍스트: 데이터 개요 + 통계 요약 + 차트 설명
- 출력: 핵심 발견사항, 비즈니스 인사이트, 권장 액션
- `OPENAI_API_KEY` 미설정 시 규칙 기반 폴백 요약 제공

## 기술 스택

- Frontend: React + Vite + TypeScript
- Backend API: FastAPI (Python Serverless for Vercel)
- Data/EDA: Pandas, NumPy
- Visualization: Matplotlib, Seaborn
- LLM: OpenAI Chat Completions
- Deployment: Vercel (Frontend + Python API)

## 실행 방법 (로컬)

### 1. Python API 실행 (포트 8787)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export MPLCONFIGDIR=/tmp/mplconfig
uvicorn api.analyze:app --host 127.0.0.1 --port 8787
```

### 2. Frontend 실행 (포트 5151)

```bash
npm install
npm run dev -- --host 127.0.0.1 --port 5151
```

브라우저 접속: `http://127.0.0.1:5151`

## API 스펙

### `POST /api/analyze`

요청 본문:

```json
{
  "csv_text": "col1,col2\na,b\n",
  "filename": "sample.csv"
}
```

응답 주요 필드:
- `overview`: 행/열, dtype, 결측치, 중복 정보
- `eda`: numeric/categorical 요약
- `charts`: base64 PNG 배열
- `insights`: LLM 또는 fallback 마크다운 리포트

## 환경 변수

| 변수 | 설명 |
|------|------|
| `OPENAI_API_KEY` | GPT 기반 인사이트 생성 키 |
| `OPENAI_MODEL` | (선택) 기본값 `gpt-4o-mini` |
| `CORS_ORIGINS` | (선택) 허용 오리진 목록 (콤마 구분) |
| `VITE_API_URL` | (선택) 프론트에서 별도 API 도메인 지정 시 사용 |

## 배포 정보

- App URL: [https://goorm-260506-data-eda-v1.vercel.app](https://goorm-260506-data-eda-v1.vercel.app)
- API Health: `GET /api/analyze`
- API Analyze: `POST /api/analyze`

## 프로젝트 구조

```text
src/
├── api/
│   └── analyze.ts
├── components/
│   ├── Upload.tsx
│   ├── Chart.tsx
│   └── Report.tsx
├── utils/
│   └── dataProcessor.ts
└── App.tsx

api/
├── analyze.py
└── pipeline.py
```

## MVP 제한 사항

- 대용량 CSV는 서버에서 최대 12,000행 샘플링
- 상관 히트맵은 수치형 상위 일부 컬럼만 사용
- 자동 리포트는 빠른 탐색용이며 도메인 정밀 분석은 추가 검증 권장
