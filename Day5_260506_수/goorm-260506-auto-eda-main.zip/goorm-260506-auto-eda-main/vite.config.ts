import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

const apiTarget = process.env.VITE_DEV_API_PROXY ?? "http://127.0.0.1:8787";

export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      // Uvicorn serves FastAPI at `/`; Vercel exposes `/api/analyze`
      "/api/analyze": {
        target: apiTarget,
        changeOrigin: true,
        rewrite: () => "/",
      },
    },
  },
});
