"""
Vercel Serverless entry: FastAPI app for /api/analyze
"""
from __future__ import annotations

import os
import sys

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

# Ensure sibling modules resolve when bundled
_API_DIR = os.path.dirname(os.path.abspath(__file__))
if _API_DIR not in sys.path:
    sys.path.insert(0, _API_DIR)

from pipeline import run_health, run_pipeline

app = FastAPI(title="EDA Agent API", version="0.1.0")

_origins = os.environ.get("CORS_ORIGINS", "*").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in _origins if o.strip()] or ["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class AnalyzeBody(BaseModel):
    csv_text: str = Field(..., description="Raw CSV file contents as UTF-8 text")
    filename: str = Field("upload.csv", description="Original filename (for logging only)")


@app.get("/")
@app.get("/api/analyze")
def root():
    return run_health()


@app.post("/")
@app.post("/api/analyze")
def analyze(body: AnalyzeBody):
    if not body.csv_text or not body.csv_text.strip():
        raise HTTPException(status_code=400, detail="csv_text is empty")
    try:
        return run_pipeline(body.csv_text, body.filename or "upload.csv")
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e)) from e
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {e}") from e
