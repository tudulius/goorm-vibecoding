"""
Multi-agent style EDA pipeline: Data Agent → Viz Agent → Insight Agent (LLM).
Inspired by Mercedes EDA notebook patterns (distribution, sorted y, boxplot, heatmap).
"""
from __future__ import annotations

import base64
import io
import json
import os
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from openai import OpenAI

# Notebook-style palette
sns.set_theme(style="whitegrid", palette="deep")

MAX_ROWS = 12_000
MAX_COLS_HEATMAP = 14
MAX_CATEGORIES_BAR = 12
CHART_FIGSIZE = (9, 5)
CHART_DPI = 110


def _safe_json(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): _safe_json(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_safe_json(x) for x in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return float(obj)
    if isinstance(obj, float):
        if np.isnan(obj) or np.isinf(obj):
            return None
        return obj
    if pd.isna(obj):
        return None
    return obj


def _load_dataframe(csv_text: str, filename: str) -> tuple[pd.DataFrame, dict[str, Any]]:
    meta: dict[str, Any] = {"filename": filename, "truncated": False, "note": None}
    buf = io.StringIO(csv_text)
    try:
        df = pd.read_csv(buf)
    except Exception as e:
        raise ValueError(f"CSV parse error: {e}") from e

    if df.shape[0] > MAX_ROWS:
        df = df.sample(n=MAX_ROWS, random_state=42).sort_index()
        meta["truncated"] = True
        meta["note"] = f"Sampled {MAX_ROWS} rows from original dataset for analysis."
    return df, meta


def _detect_target_column(df: pd.DataFrame) -> str | None:
    cols_lower = {c.lower(): c for c in df.columns}
    for key in ("y", "target", "label"):
        if key in cols_lower:
            return cols_lower[key]
    # Prefer a numeric column named like *price*, *score*
    for c in df.columns:
        cl = c.lower()
        if any(k in cl for k in ("target", "label", "price", "sales")):
            if pd.api.types.is_numeric_dtype(df[c]):
                return c
    return None


def _numeric_columns(df: pd.DataFrame) -> list[str]:
    return [
        c
        for c in df.columns
        if pd.api.types.is_numeric_dtype(df[c]) and df[c].notna().sum() > 1
    ]


def _categorical_columns(df: pd.DataFrame) -> list[str]:
    out: list[str] = []
    for c in df.columns:
        if pd.api.types.is_object_dtype(df[c]) or pd.api.types.is_categorical_dtype(df[c]):
            if df[c].nunique(dropna=True) <= 200:
                out.append(c)
        elif pd.api.types.is_numeric_dtype(df[c]) and df[c].nunique(dropna=True) <= 15:
            out.append(c)
    return out


def _fig_to_b64(fig: plt.Figure) -> str:
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=CHART_DPI, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _data_agent_overview(df: pd.DataFrame, load_meta: dict[str, Any]) -> dict[str, Any]:
    missing = df.isnull().sum()
    dtypes = {str(k): str(v) for k, v in df.dtypes.items()}
    return {
        "rows": int(df.shape[0]),
        "columns": int(df.shape[1]),
        "column_names": list(df.columns.astype(str)),
        "dtypes": dtypes,
        "missing_counts": {str(k): int(v) for k, v in missing.items() if v > 0},
        "missing_total_cells": int(missing.sum()),
        "duplicate_rows": int(df.duplicated().sum()),
        "load_meta": load_meta,
    }


def _data_agent_eda(df: pd.DataFrame) -> dict[str, Any]:
    num_cols = _numeric_columns(df)
    cat_cols = _categorical_columns(df)
    desc = None
    if num_cols:
        desc_df = df[num_cols].describe(include=np.number).T
        desc = _safe_json(desc_df.round(6).replace({np.nan: None}).to_dict(orient="index"))
    cat_summary = {}
    for c in cat_cols[:30]:
        cat_summary[str(c)] = int(df[c].nunique(dropna=True))
    return {
        "numeric_columns": num_cols,
        "categorical_columns": cat_cols,
        "describe_numeric": desc,
        "categorical_cardinality": cat_summary,
    }


def _pick_boxplot_cat(df: pd.DataFrame, target: str, cat_cols: list[str]) -> str | None:
    for c in cat_cols:
        if c == target:
            continue
        n = df[c].nunique(dropna=True)
        if 2 <= n <= 20:
            return c
    for c in cat_cols:
        if c == target:
            continue
        n = df[c].nunique(dropna=True)
        if n <= 40:
            return c
    return None


def _best_scatter_pair(df: pd.DataFrame, num_cols: list[str]) -> tuple[str, str] | None:
    if len(num_cols) < 2:
        return None
    sub = df[num_cols].dropna()
    if len(sub) < 20:
        return num_cols[0], num_cols[1]
    corr = sub.corr(numeric_only=True).abs()
    pairs: list[tuple[float, str, str]] = []
    for i, a in enumerate(num_cols):
        for b in num_cols[i + 1 :]:
            if a in corr.index and b in corr.columns:
                pairs.append((float(corr.loc[a, b]), a, b))
    if not pairs:
        return num_cols[0], num_cols[1]
    pairs.sort(reverse=True)
    return pairs[0][1], pairs[0][2]


def _viz_agent_charts(
    df: pd.DataFrame, _overview: dict[str, Any], eda: dict[str, Any]
) -> tuple[list[dict[str, Any]], list[str]]:
    charts: list[dict[str, Any]] = []
    captions: list[str] = []
    target = _detect_target_column(df)
    num_cols = eda["numeric_columns"]
    cat_cols = eda["categorical_columns"]

    # 1) Histogram — target or first numeric (notebook: distplot of y)
    hist_col = target if target and target in num_cols else (num_cols[0] if num_cols else None)
    if hist_col:
        fig, ax = plt.subplots(figsize=CHART_FIGSIZE)
        s = pd.to_numeric(df[hist_col], errors="coerce").dropna()
        if len(s) > 0:
            sns.histplot(s, bins=min(50, max(10, int(np.sqrt(len(s))))), kde=True, ax=ax)
            ax.set_title(f"Distribution of {hist_col}")
            ax.set_xlabel(hist_col)
            charts.append(
                {
                    "id": "hist_primary",
                    "title": f"Histogram / KDE: {hist_col}",
                    "kind": "histogram",
                    "description": "Numeric distribution with density curve.",
                    "image_base64": _fig_to_b64(fig),
                }
            )
            captions.append(f"Histogram for `{hist_col}` ({len(s)} non-null values).")

    # 2) Sorted target vs index (notebook: scatter of sorted y)
    if target and target in num_cols:
        fig, ax = plt.subplots(figsize=CHART_FIGSIZE)
        yv = pd.to_numeric(df[target], errors="coerce").dropna().sort_values().values
        if len(yv) > 0:
            ax.scatter(range(len(yv)), yv, alpha=0.35, s=12)
            ax.set_xlabel("index (sorted)")
            ax.set_ylabel(target)
            ax.set_title(f"Sorted {target} vs index")
            charts.append(
                {
                    "id": "sorted_target",
                    "title": f"Sorted {target} (rank plot)",
                    "kind": "scatter_sorted",
                    "description": "Ordered target values; highlights tails and plateaus.",
                    "image_base64": _fig_to_b64(fig),
                }
            )
            captions.append(f"Sorted values of `{target}` to inspect tails and spread.")

    # 3) Bar — top categorical
    bar_col = None
    for c in cat_cols:
        if df[c].nunique(dropna=True) <= 50:
            bar_col = c
            break
    if bar_col:
        fig, ax = plt.subplots(figsize=CHART_FIGSIZE)
        vc = df[bar_col].astype(str).value_counts().head(MAX_CATEGORIES_BAR)
        sns.barplot(x=vc.values, y=vc.index, ax=ax, orient="h")
        ax.set_title(f"Top categories: {bar_col}")
        ax.set_xlabel("count")
        charts.append(
            {
                "id": "bar_categorical",
                "title": f"Bar chart: {bar_col}",
                "kind": "bar",
                "description": "Most frequent categorical levels.",
                "image_base64": _fig_to_b64(fig),
            }
        )
        captions.append(f"Bar chart for `{bar_col}` (top {len(vc)} levels).")

    # 4) Correlation heatmap
    if len(num_cols) >= 2:
        cols_h = num_cols[:MAX_COLS_HEATMAP]
        cmat = df[cols_h].corr(numeric_only=True)
        fig, ax = plt.subplots(figsize=(min(10, 0.5 + len(cols_h)), min(9, 0.45 + len(cols_h))))
        sns.heatmap(cmat, ax=ax, cmap="RdBu_r", center=0, annot=len(cols_h) <= 10, fmt=".2f")
        ax.set_title("Correlation heatmap (numeric subset)")
        charts.append(
            {
                "id": "corr_heatmap",
                "title": "Correlation heatmap",
                "kind": "heatmap",
                "description": "Linear relationships between numeric features (subset).",
                "image_base64": _fig_to_b64(fig),
            }
        )
        captions.append(
            f"Correlation heatmap over {len(cols_h)} numeric columns (full list truncated if wide)."
        )

    # 5) Scatter — strongest pair
    pair = _best_scatter_pair(df, num_cols)
    if pair:
        a, b = pair
        if a != b:
            fig, ax = plt.subplots(figsize=CHART_FIGSIZE)
            sub = df[[a, b]].dropna()
            if len(sub) > 0:
                ax.scatter(sub[a], sub[b], alpha=0.35, s=14)
                ax.set_xlabel(a)
                ax.set_ylabel(b)
                ax.set_title(f"Scatter: {a} vs {b}")
                charts.append(
                    {
                        "id": "scatter_pair",
                        "title": f"Scatter: {a} vs {b}",
                        "kind": "scatter",
                        "description": "Bivariate relationship between two numeric columns.",
                        "image_base64": _fig_to_b64(fig),
                    }
                )
                captions.append(f"Scatter plot `{a}` vs `{b}` (n={len(sub)}).")

    # 6) Boxplot — category vs target / numeric
    box_cat = None
    box_y = None
    if target and target in num_cols:
        box_cat = _pick_boxplot_cat(df, target, cat_cols)
        box_y = target
    elif num_cols and cat_cols:
        box_cat = _pick_boxplot_cat(df, cat_cols[0], cat_cols) or cat_cols[0]
        box_y = num_cols[0]
    if box_cat and box_y and box_cat != box_y:
        fig, ax = plt.subplots(figsize=CHART_FIGSIZE)
        plot_df = df[[box_cat, box_y]].dropna()
        if len(plot_df) > 5 and plot_df[box_cat].nunique() <= 25:
            order = plot_df[box_cat].astype(str).value_counts().index.tolist()[:20]
            sns.boxplot(
                data=plot_df[plot_df[box_cat].astype(str).isin(order)],
                x=box_cat,
                y=box_y,
                order=order,
                ax=ax,
            )
            ax.set_title(f"Boxplot: {box_y} by {box_cat}")
            plt.xticks(rotation=35, ha="right")
            charts.append(
                {
                    "id": "boxplot",
                    "title": f"Boxplot: {box_y} by {box_cat}",
                    "kind": "boxplot",
                    "description": "Distribution of numeric variable across categories.",
                    "image_base64": _fig_to_b64(fig),
                }
            )
            captions.append(f"Boxplot of `{box_y}` across `{box_cat}`.")

    return charts, captions


def _insight_agent_llm(
    overview: dict[str, Any],
    eda: dict[str, Any],
    chart_captions: list[str],
) -> dict[str, Any]:
    api_key = os.environ.get("OPENAI_API_KEY")
    sys_prompt = (
        "You are a senior data analyst. Given structured EDA summaries and chart descriptions, "
        "produce actionable, non-hallucinated insights. If information is missing, say so briefly."
    )
    user_block = json.dumps(
        {
            "overview": overview,
            "eda_highlights": {
                "numeric_columns": eda.get("numeric_columns"),
                "categorical_columns": eda.get("categorical_columns")[:25],
                "categorical_cardinality": dict(list(eda.get("categorical_cardinality", {}).items())[:20]),
            },
            "chart_descriptions": chart_captions,
        },
        ensure_ascii=False,
        indent=2,
    )
    user_msg = (
        f"{user_block}\n\n"
        "Generate:\n"
        "1. Key findings (3–5 bullet points)\n"
        "2. Business insights (2–4 sentences)\n"
        "3. Recommended next actions (2–4 bullets)\n"
        "Respond in Korean. Use clear markdown-style headings."
    )

    if not api_key:
        return {
            "source": "fallback",
            "markdown": _fallback_insights(overview, eda, chart_captions),
        }

    try:
        client = OpenAI(api_key=api_key)
        resp = client.chat.completions.create(
            model=os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            messages=[
                {"role": "system", "content": sys_prompt},
                {"role": "user", "content": user_msg},
            ],
            temperature=0.35,
            max_tokens=1200,
        )
        text = (resp.choices[0].message.content or "").strip()
        return {"source": "openai", "markdown": text}
    except Exception as e:
        return {
            "source": "error",
            "markdown": _fallback_insights(overview, eda, chart_captions)
            + f"\n\n*(LLM 호출 실패: {e})*",
        }


def _fallback_insights(
    overview: dict[str, Any], eda: dict[str, Any], chart_captions: list[str]
) -> str:
    rows, cols = overview["rows"], overview["columns"]
    miss = overview.get("missing_total_cells", 0)
    nums = len(eda.get("numeric_columns") or [])
    cats = len(eda.get("categorical_columns") or [])
    lines = [
        "## 자동 요약 (LLM 키 없음)",
        f"- 표 크기: **{rows:,}**행 × **{cols}**열",
        f"- 수치형 **{nums}**개, 범주형(저·중 카디널리티) **{cats}**개",
        f"- 결측 셀 합계: **{miss:,}**",
        "### 차트에서 본 것",
    ]
    lines.extend(f"- {c}" for c in chart_captions[:6])
    lines.append(
        "\n### 권장\n"
        "- `OPENAI_API_KEY`를 설정하면 LLM 기반 인사이트로 확장됩니다.\n"
        "- 타겟 변수가 있다면 열 이름을 `y` 또는 `target`으로 두면 박스플롯·정렬 플롯이 더 정확해집니다."
    )
    return "\n".join(lines)


def run_pipeline(csv_text: str, filename: str) -> dict[str, Any]:
    """Planner orchestrates Data → Viz → Insight agents."""
    df, load_meta = _load_dataframe(csv_text, filename)
    overview = _data_agent_overview(df, load_meta)
    eda = _data_agent_eda(df)
    charts, captions = _viz_agent_charts(df, overview, eda)
    insights = _insight_agent_llm(overview, eda, captions)

    target_guess = _detect_target_column(df)
    report = {
        "workflow_version": "mvp-1",
        "agents": [
            {"name": "Planner", "role": "Orchestrate pipeline"},
            {"name": "Data Agent", "role": "Schema, missing, describe, cardinality"},
            {"name": "Viz Agent", "role": "Auto chart selection (4–6 charts)"},
            {"name": "Insight Agent", "role": "LLM narrative + fallback"},
        ],
        "target_column_guess": target_guess,
        "overview": overview,
        "eda": eda,
        "charts": charts,
        "insights": insights,
    }
    return _safe_json(report)


def run_health() -> dict[str, str]:
    return {"status": "ok", "service": "eda-agent-api"}
