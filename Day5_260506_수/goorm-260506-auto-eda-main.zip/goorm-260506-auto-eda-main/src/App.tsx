import { useCallback, useState } from "react";
import { analyzeCsv } from "./api/analyze";
import { Report } from "./components/Report";
import { Upload } from "./components/Upload";
import type { AnalyzeResponse } from "./types";
import { assertCsvSize } from "./utils/dataProcessor";

export default function App() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalyzeResponse | null>(null);
  const [fileName, setFileName] = useState<string | null>(null);

  const run = useCallback(async (text: string, name: string) => {
    setError(null);
    setResult(null);
    setLoading(true);
    setFileName(name);
    try {
      assertCsvSize(text);
      const data = await analyzeCsv(text, name);
      setResult(data);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }, []);

  return (
    <div className="app">
      <header className="hero">
        <p className="eyebrow">MVP · Agentic EDA</p>
        <h1>자동화된 데이터 분석 AI 에이전트</h1>
        <p className="lede">
          CSV를 올리면 <strong>Data → Viz → Insight</strong> 파이프라인이 개요·통계·4–6개 차트·LLM 리포트를
          생성합니다. Mercedes EDA 노트북 스타일의 분포·정렬·박스·히트맵을 자동 선택합니다.
        </p>
      </header>

      <Upload
        disabled={loading}
        onFile={(text, name) => {
          void run(text, name);
        }}
      />

      <div className="actions">
        {loading && (
          <span className="spinner" aria-live="polite">
            분석 중…
          </span>
        )}
      </div>

      {error && (
        <div className="banner banner--error" role="alert">
          {error}
        </div>
      )}

      {fileName && !error && (
        <p className="file-tag">
          현재 파일: <code>{fileName}</code>
        </p>
      )}

      {result && <Report data={result} />}

      <footer className="footer">
        <p>
          배포: Vercel · API: FastAPI + Pandas · 시각화: Matplotlib/Seaborn · 인사이트:{" "}
          <code>OPENAI_API_KEY</code> (없으면 폴백)
        </p>
      </footer>
    </div>
  );
}
