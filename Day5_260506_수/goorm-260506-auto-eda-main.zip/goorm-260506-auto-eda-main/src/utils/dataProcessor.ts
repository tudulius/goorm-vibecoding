/** Lightweight client-side guardrails before upload */
export const MAX_CLIENT_CHARS = 12 * 1024 * 1024; // ~12MB text

export function assertCsvSize(text: string): void {
  if (text.length > MAX_CLIENT_CHARS) {
    throw new Error(
      `파일이 너무 큽니다 (>${Math.round(MAX_CLIENT_CHARS / 1024 / 1024)}MB). 샘플링된 CSV로 시도해 주세요.`,
    );
  }
}

export async function readFileAsText(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(reader.error ?? new Error("read failed"));
    reader.readAsText(file, "UTF-8");
  });
}
