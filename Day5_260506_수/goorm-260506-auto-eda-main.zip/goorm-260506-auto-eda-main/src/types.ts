export type ChartItem = {
  id: string;
  title: string;
  kind: string;
  description: string;
  image_base64: string;
};

export type AgentInfo = { name: string; role: string };

export type AnalyzeResponse = {
  workflow_version: string;
  agents: AgentInfo[];
  target_column_guess: string | null;
  overview: {
    rows: number;
    columns: number;
    column_names: string[];
    dtypes: Record<string, string>;
    missing_counts: Record<string, number>;
    missing_total_cells: number;
    duplicate_rows: number;
    load_meta: {
      filename: string;
      truncated: boolean;
      note: string | null;
    };
  };
  eda: {
    numeric_columns: string[];
    categorical_columns: string[];
    describe_numeric: Record<string, Record<string, number | null>> | null;
    categorical_cardinality: Record<string, number>;
  };
  charts: ChartItem[];
  insights: {
    source: string;
    markdown: string;
  };
};
