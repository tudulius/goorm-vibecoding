import ReactMarkdown from "react-markdown";
import type { AnalyzeResponse } from "../types";
import { Chart } from "./Chart";

type Props = {
  data: AnalyzeResponse;
};

export function Report({ data }: Props) {
  const { overview, eda, charts, insights, agents, target_column_guess } = data;

  return (
    <div className="report">
      <section className="report-section">
        <h2>에이전트 워크플로</h2>
        <ul className="agent-list">
          {agents.map((a) => (
            <li key={a.name}>
              <strong>{a.name}</strong>
              <span>{a.role}</span>
            </li>
          ))}
        </ul>
        {target_column_guess && (
          <p className="muted">
            추정 타겟 열: <code>{target_column_guess}</code>
          </p>
        )}
      </section>

      <section className="report-section">
        <h2>데이터 개요</h2>
        <div className="stat-grid">
          <div className="stat">
            <span className="stat-label">행</span>
            <span className="stat-value">{overview.rows.toLocaleString()}</span>
          </div>
          <div className="stat">
            <span className="stat-label">열</span>
            <span className="stat-value">{overview.columns}</span>
          </div>
          <div className="stat">
            <span className="stat-label">결측 셀</span>
            <span className="stat-value">{overview.missing_total_cells.toLocaleString()}</span>
          </div>
          <div className="stat">
            <span className="stat-label">중복 행</span>
            <span className="stat-value">{overview.duplicate_rows.toLocaleString()}</span>
          </div>
        </div>
        {overview.load_meta.truncated && overview.load_meta.note && (
          <p className="banner banner--warn">{overview.load_meta.note}</p>
        )}
        <details className="details-block">
          <summary>컬럼 &amp; 타입</summary>
          <div className="table-scroll">
            <table className="data-table">
              <thead>
                <tr>
                  <th>컬럼</th>
                  <th>dtype</th>
                  <th>결측</th>
                </tr>
              </thead>
              <tbody>
                {overview.column_names.map((c) => (
                  <tr key={c}>
                    <td>
                      <code>{c}</code>
                    </td>
                    <td>{overview.dtypes[c] ?? "—"}</td>
                    <td>{overview.missing_counts[c] ?? 0}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </details>
      </section>

      <section className="report-section">
        <h2>EDA 요약</h2>
        <p className="muted">
          수치형 {eda.numeric_columns.length}개 · 범주형 후보 {eda.categorical_columns.length}개
        </p>
        {eda.describe_numeric && (
          <details className="details-block" open>
            <summary>수치형 describe()</summary>
            <div className="table-scroll">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>column</th>
                    <th>count</th>
                    <th>mean</th>
                    <th>std</th>
                    <th>min</th>
                    <th>25%</th>
                    <th>50%</th>
                    <th>75%</th>
                    <th>max</th>
                  </tr>
                </thead>
                <tbody>
                  {Object.entries(eda.describe_numeric).map(([col, row]) => (
                    <tr key={col}>
                      <td>
                        <code>{col}</code>
                      </td>
                      {["count", "mean", "std", "min", "25%", "50%", "75%", "max"].map((k) => (
                        <td key={k}>{fmt(row[k])}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </details>
        )}
      </section>

      <section className="report-section">
        <h2>시각화 ({charts.length})</h2>
        <p className="muted">Python · Matplotlib / Seaborn (서버 렌더링 PNG)</p>
        <div className="chart-grid">
          {charts.map((c) => (
            <Chart key={c.id} chart={c} />
          ))}
        </div>
      </section>

      <section className="report-section report-section--insights">
        <h2>인사이트</h2>
        <p className="muted">
          소스: {insights.source === "openai" ? "OpenAI" : insights.source === "fallback" ? "규칙 기반 폴백" : "혼합"}
        </p>
        <div className="markdown-body">
          <ReactMarkdown>{insights.markdown}</ReactMarkdown>
        </div>
      </section>
    </div>
  );
}

function fmt(v: number | null | undefined): string {
  if (v === null || v === undefined) return "—";
  if (typeof v !== "number") return String(v);
  if (Math.abs(v) >= 1e6 || (Math.abs(v) < 1e-3 && v !== 0)) return v.toExponential(3);
  return Number.isInteger(v) ? String(v) : v.toFixed(4).replace(/\.?0+$/, "");
}
