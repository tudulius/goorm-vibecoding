import { useCallback, useState } from "react";

type Props = {
  disabled: boolean;
  onFile: (text: string, name: string) => void;
};

export function Upload({ disabled, onFile }: Props) {
  const [drag, setDrag] = useState(false);

  const handleFiles = useCallback(
    async (files: FileList | null) => {
      const f = files?.[0];
      if (!f) return;
      if (!f.name.toLowerCase().endsWith(".csv")) {
        alert("CSV 파일만 업로드할 수 있습니다.");
        return;
      }
      const text = await f.text();
      onFile(text, f.name);
    },
    [onFile],
  );

  return (
    <div
      className={`upload-zone ${drag ? "upload-zone--active" : ""} ${disabled ? "upload-zone--disabled" : ""}`}
      onDragOver={(e) => {
        e.preventDefault();
        if (!disabled) setDrag(true);
      }}
      onDragLeave={() => setDrag(false)}
      onDrop={(e) => {
        e.preventDefault();
        setDrag(false);
        if (!disabled) void handleFiles(e.dataTransfer.files);
      }}
    >
      <input
        id="csv-input"
        type="file"
        accept=".csv,text/csv"
        className="upload-input"
        disabled={disabled}
        onChange={(e) => void handleFiles(e.target.files)}
      />
      <label htmlFor="csv-input" className="upload-label">
        <span className="upload-title">CSV 업로드</span>
        <span className="upload-hint">드래그 앤 드롭 또는 클릭 · 최대 약 12MB (텍스트)</span>
      </label>
    </div>
  );
}
