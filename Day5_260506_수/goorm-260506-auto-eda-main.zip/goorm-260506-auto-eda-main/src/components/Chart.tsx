import type { ChartItem } from "../types";

type Props = {
  chart: ChartItem;
};

export function Chart({ chart }: Props) {
  const src = `data:image/png;base64,${chart.image_base64}`;
  return (
    <article className="chart-card">
      <header className="chart-card__head">
        <h3>{chart.title}</h3>
        <span className="chart-card__kind">{chart.kind}</span>
      </header>
      <p className="chart-card__desc">{chart.description}</p>
      <div className="chart-card__img-wrap">
        <img src={src} alt={chart.title} loading="lazy" className="chart-card__img" />
      </div>
    </article>
  );
}
