---
name: NextAI Studio 기술명세
overview: HTML/CSS/JS 싱글 페이지로, [cursor.com/product](https://cursor.com/product)의 정보 구조를 참고하되 브랜드는 **NextAI Studio**에 맞추고, 시각적 톤은 **Claude 메인 테마**(웜 뉴트럴 배경·코랄/테라코타 액센트)로 정의하는 구현용 기술명세서입니다.
todos:
  - id: finalize-copy
    content: 섹션별 한/영 카피·서비스 항목(슬랙·원격 등) 확정
    status: completed
  - id: html-ia
    content: index.html에 시맨틱 섹션·앵커 ID 구조 반영
    status: completed
  - id: claude-tokens
    content: styles.css에 Claude 톤 CSS 변수·타이포·그리드 정의
    status: completed
  - id: js-a11y
    content: script.js에 네비·스크롤·reduced-motion 고려
    status: completed
isProject: false
---

# NextAI Studio — 웹페이지 구현 기술명세서 (Specification)

## 1. 프로젝트 목적

- **대상**: 바이브코딩 입문자가 에이전트와 함께 구현할 수 있는 **에이전시 소개용 랜딩 페이지**의 범위·구조·품질 기준을 문서화한다.
- **브랜드**: **NextAI Studio**
- **핵심 제안 가치(Value Proposition)**: **AI 에이전트를 활용한 현대적인 애플리케이션 빌드** (기획·구현·운영 전 과정에서 에이전트 역할을 명확히 드러낼 것)

## 2. 기술 제약 (필수)


| 항목         | 요구                                                                |
| ---------- | ----------------------------------------------------------------- |
| 마크업/스타일/동작 | **HTML, CSS, JavaScript만** (프레임워크·빌드 도구 없이도 동작 가능한 정적 파일 기준으로 명세) |
| 페이지 수      | **싱글 페이지(SPA 아님)** — 한 개의 `index.html` + 연결된 CSS/JS               |
| 데이터        | 정적 콘텐츠 위주(필요 시 JS로 스크롤·탭·아코디언 등 경량 인터랙션만)                         |


## 3. 참조: cursor.com/product 정보 구조 → NextAI 매핑

[Cursor Product](https://cursor.com/product)는 **히어로 → 제품 서피스(데스크톱/CLI/기타) → 웹·모바일 → 심층 이해(코드베이스·모델·인덱싱·팀 룰) → 전체 라이프사이클(Plan/Design/Debug) → 실무 도구(터미널·컨텍스트·Git) → 확장(플러그인·스킬·MCP) → 사회적 증거(인용) → 최신 하이라이트·체인지로그 → 최종 CTA** 흐름을 가진다.

에이전시 소개에 맞게 **동일한 “스크롤 스토리텔링” 골격**을 유지하되, 용어·카피는 **NextAI Studio 서비스**로 치환한다.

**권장 섹션 순서(IA)**

1. **Hero** — Cursor의 *“Turn ideas into code / Delegate implementation…”*에 대응: 아이디어를 **에이전트와 함께** 제품으로 만든다는 한 줄 헤드라인 + 보조 카피 + 주요 CTA(문의·포트폴리오 등).
2. **Everywhere / 서비스·채널** — *Desktop / CLI / Other Surfaces*에 대응: **어디서 어떻게 협업하는지** (예: 워크숍형 컨설팅, 기존 레포 연동 개발, 슬랙·기타 채널 연동 등 — 실제 제공 범위에 맞게 3~4개 카드).
3. **클라우드·비동형 협업(선택)** — *Web & Mobile / cloud agents*에 대응: 원격 비동 작업·데모 접근 등 에이전시 특성에 맞는 한 블록(짧게).
4. **심층 이해** — *Understands your codebase…*에 대응: **도메인·레거시·비즈니스 맥락**을 에이전트가 어떻게 흡수하는지 (코드 인덱싱 비유 대신 요구사항·문서화·디자인 시스템 정렬 등).
5. **에이전트 역량** — *Multiple models / subagents*에 대응: **병렬 탐색·역할 분담**(기획 에이전트 / 구현 에이전트 / 리뷰 등)을 한눈에.
6. **방법론·규칙** — *Team rules*에 대응: **팀 규칙·코딩 컨벤션·브랜드 가이드**를 에이전트에 주입하는 방식.
7. **전체 라이프사이클** — *Plan / Design / Debug*에 대응: **기획(Plan) → 구현·UI(Design) → 검증·수정(Debug)** — 각각 1~2문단 + 시각적 UI 목(mock) 스크린샷 대신 **플레이스홀더 카드/스텝퍼**로 표현 가능.
8. **실무 역량** — *Terminal / Add context / Git*에 대응: **빌드·배포 파이프라인, 컨텍스트 주입(@멘션 유사 개념), 버전 관리·롤백**을 에이전시 산출물 관점으로 서술.
9. **확장·생태계** — *Plugins / Skills / MCP*에 대응: **도구 연동, 커스텀 스킬/프롬프트, MCP·API 연동**으로 확장 가능함을 강조(기술 스택 나열은 선택).
10. **신뢰** — *Trusted by…*에 대응: **짧은 추천 인용 2~4개** (가상이면 “데모용” 표기 권장) 또는 **로고 스트립 플레이스홀더**.
11. **하이라이트·업데이트(선택)** — *Recent highlights / Changelog*에 대응: 블로그가 없으면 **“최근 프로젝트” 카드 2~3개** 또는 **로드맵 한 줄**.
12. **최종 CTA** — *Try Cursor now*에 대응: **문의하기 / 미팅 잡기** 등 단일 명확한 액션.

이 순서를 **반드시 전부 채울 필요는 없으나**, Cursor 페이지와 같은 **깊이감**을 위해 최소한 **Hero → 서비스/채널 → 방법론(Plan/Debug) → 신뢰 → CTA**는 포함하는 것을 권장한다.

```mermaid
flowchart TB
  subgraph aboveFold [Above the fold]
    Hero[Hero_NextAI]
  end
  subgraph story [Scroll story]
    Surfaces[Services_Surfaces]
    Deep[Deep_Context]
    Agents[Agent_Capabilities]
    Lifecycle[Plan_Design_Debug]
    Tools[Build_Context_Version]
    Extend[Plugins_Skills_Integrations]
  end
  subgraph close [Closing]
    Social[Trust_Quotes]
    CTA[Final_CTA]
  end
  Hero --> Surfaces --> Deep --> Agents --> Lifecycle --> Tools --> Extend --> Social --> CTA
```



## 4. 디자인 시스템: Claude 메인 테마 (구현 지침)

공식 브랜드 가이드 PDF가 없다고 가정하고, **“Claude 랜딩에서 느껴지는 톤”**을 재현 가능한 토큰으로 고정한다.

- **색**: 웜 오프화이트/크림 **배경**, 본문은 **워밍 다크 브라운/차콜**, 포인트는 **테라코타·코럴**(CTA·링크·강조) — 과한 채도 대신 차분한 톤.
- **타이포**: 헤드라인은 산세리프(고독 `**system-ui`/Inter 계열**)로 가독성 우선; 본문 줄간격 넉넉히. (Claude처럼 **세리프 보조**를 쓰려면 선택적으로 헤드라인만 세리프 1종.)
- **라운드**: 버튼·카드 `**border-radius` 중간~크게**(친근·부드러운 인상).
- **그림자**: 낮은 대비 소프트 쉐도우로 카드 플로팅 (다크 패턴 없음).
- **모션**: `prefers-reduced-motion` 존중; 스크롤 시 **미세 페이드/슬라이드만** 허용.
- **구현 방법**: `:root`에 **CSS 변수**로 색·간격·라운드를 정의해 한 파일에서 테마 교체 가능하게 명시.

## 5. 레이아웃·컴포넌트 패턴

- **네비게이션**: 상단 고정 또는 스크롤 시 축소; 앵커 링크로 같은 페이지 내 섹션 이동 (`#services`, `#lifecycle` 등).
- **그리드**: 데스크톱 다열, 모바일 단열 — **반응형**(미디어쿼리 필수).
- **반복 블록**: Cursor식 **좌측 카피 + 우측 일러스트/목업** 교차 배치 가능(짝수 섹션마다 좌우 반전하면 리듬감 형성).

## 6. 파일·자산 구조 (제안)

- `index.html` — 시맨틱 태그(`header`, `main`, `section`, `footer`), 메타 디스크립션에 NextAI 한 줄 요약
- `styles.css` — 테마 변수, 레이아웃, 반응형
- `script.js` — 모바일 메뉴 토글, 스무스 스크롤, (선택) 섹션 `IntersectionObserver`로 페이드인
- `assets/` — 로고 SVG, 선택적 영상/이미지

## 7. 접근성·SEO·품질 (비기능)

- 모든 인터랙티브 요소 **키보드 포커스** 가능; 버튼/링크 명확한 라벨
- 의미 있는 `title`, `meta description`, `lang="ko"` (카피가 한국어면)
- 린터 없더라도 **시맨틱 마크업**과 **색 대비** 점검 (본문 대비 최소 WCAG 신경)
- 외부 링크는 `rel="noopener noreferrer"` 패턴 명시

## 8. 콘텐츠 작성 시 체크리스트

- 모든 섹션에 **NextAI Studio** 이름 또는 암시적 일관성
- “에이전트”만 반복하지 말고 **고객 결과물**(속도·품질·현대적 스택)을 구체화
- Cursor 페이지의 **기능 나열을 그대로 베끼지 말고**, 에이전시 **서비스 언어로 재서술**

## 9. 구현 단계 제안 (명세 이후)

1. HTML 뼈대 + 앵커 IA
2. Claude 테마 CSS 변수·타이포·그리드
3. 섹션별 카피 삽입 및 반응형 다듬기
4. JS 경량 인터랙션 + 접근성 패스
5. 정적 호스팅(GitHub Pages 등) 시 경로·에셋 상대경로 확인

---

이 문서는 **코드 작성 전 합의용 스펙**으로 쓰면 되고, 실제 카피·서비스 항목(예: 슬랙 연동 제공 여부)은 비즈니스 결정에 따라 섹션 3의 플레이스홀더를 채우면 된다.